package com.htc.patient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicmanagementthreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
